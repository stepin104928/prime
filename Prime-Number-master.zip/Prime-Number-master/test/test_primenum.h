#ifndef __TEST_PRIMENUM_H__
#define __TEST_PRIMENUM_H__

int test_main(void);

#endif /* #ifndef __TEST_PRIMENUM_H__ */

