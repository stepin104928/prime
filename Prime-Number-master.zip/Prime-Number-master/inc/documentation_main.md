@mainpage Prime Number Application by Rajini
@subpage primenum.h
