var searchData=
[
  ['prime_20number_20application_20by_20rajini_0',['Prime Number Application by Rajini',['../index.html',1,'']]],
  ['primenum_1',['primenum',['../primenum_8h.html#a03a29494edbb654e2beeb6a1c402812b',1,'primenum.h']]],
  ['primenum_2eh_2',['primenum.h',['../primenum_8h.html',1,'']]]
];
