var searchData=
[
  ['primenum_2eh_3',['primenum.h',['../primenum_8h.html',1,'']]]
];
