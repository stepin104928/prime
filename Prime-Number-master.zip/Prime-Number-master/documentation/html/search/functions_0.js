var searchData=
[
  ['primenum_4',['primenum',['../primenum_8h.html#a03a29494edbb654e2beeb6a1c402812b',1,'primenum.h']]]
];
