# Prime-Number

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/265d34ea661e486d86ac5e36ddebefa3)](https://app.codacy.com/manual/stepin104747/Prime-Number?utm_source=github.com&utm_medium=referral&utm_content=stepin104747/Prime-Number&utm_campaign=Badge_Grade_Dashboard)

![cppcheck-action](https://github.com/stepin104747/Prime-Number/workflows/cppcheck-action/badge.svg)
